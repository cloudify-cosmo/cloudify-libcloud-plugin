cloudify-libcloud-plugin
========================

Cloudify Libcloud plugin
